package com.accenture.lkm.dao;

import com.accenture.lkm.businessbean.EmployeeBean;

public interface EmployeeDAO {
	
	Integer addEmployeeTest1(EmployeeBean employee) throws Exception;
	Integer addEmployeeTest2(EmployeeBean employee) throws Exception;
	Integer addEmployeeTest3(EmployeeBean employee) throws Exception;
	
}
