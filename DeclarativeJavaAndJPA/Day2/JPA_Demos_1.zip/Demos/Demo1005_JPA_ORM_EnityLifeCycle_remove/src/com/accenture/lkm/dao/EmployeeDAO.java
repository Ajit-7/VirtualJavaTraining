package com.accenture.lkm.dao;

public interface EmployeeDAO {
	
	public void removeEmployeeById(int id) throws Exception;
	
}
