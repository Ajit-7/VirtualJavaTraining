package com.accenture.lkm.service;

import com.accenture.lkm.businessbean.AssetBean;
import com.accenture.lkm.businessbean.EmployeeBean;

public interface EmployeeService {
	public void getAllEmployeesWithAssetDetails() throws Exception;

}
