package com.accenture.lkm.businessbean;

public class AssetBean {
	
	private Integer assetId;
	private String assetBrandName;
	private Integer validityYears;
	
	public Integer getAssetId() {
		return assetId;
	}
	public void setAssetId(Integer assetId) {
		this.assetId = assetId;
	}
	public String getAssetBrandName() {
		return assetBrandName;
	}
	public void setAssetBrandName(String assetBrandName) {
		this.assetBrandName = assetBrandName;
	}
	public Integer getValidityYears() {
		return validityYears;
	}
	public void setValidityYears(Integer validityYears) {
		this.validityYears = validityYears;
	}
	

}
