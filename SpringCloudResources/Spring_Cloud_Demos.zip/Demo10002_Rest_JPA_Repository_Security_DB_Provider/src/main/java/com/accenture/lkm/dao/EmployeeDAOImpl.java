package com.accenture.lkm.dao;

public class EmployeeDAOImpl {
	

}
