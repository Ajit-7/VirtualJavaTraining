package com.accenture.lkm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatwayService {

	public static void main(String[] args) {	
		SpringApplication.run(GatwayService.class, args);
	}
}
//http://localhost:8083/emp/controller/getDetails
//http://localhost:8083/student/controller/getDetails