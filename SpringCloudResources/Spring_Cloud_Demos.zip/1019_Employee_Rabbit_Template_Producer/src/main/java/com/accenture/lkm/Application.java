package com.accenture.lkm;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {
	public final static String queueName = "dummy-queue";
	public final static String messageKey = "spring.boot.employee.message";
	public final static String bindingPattern = "spring.#";
	
	//Creating Queue
	@Bean
	public Queue queue() {
		System.out.println("From Application:> Queue Created");
		return new Queue(queueName, false);
	}
	
	// Creating Exchange
	@Bean
	public TopicExchange exchange() {
		System.out.println("From Application:> Exchange Topic Created");
		return new TopicExchange("spring-boot-topic-exchange");
	}
	
	//Binding between Exchange and Queue using binding pattern key
	@Bean
	public Binding binding(Queue queue, TopicExchange exchange) {
		System.out.println("From Application:> Binding done");
		return BindingBuilder.bind(queue).to(exchange).with(bindingPattern);
	}

	// Used to Convert the Message Body to JSON and Send to exchange  
	@Bean
	public Jackson2JsonMessageConverter jsonConverter() {
		Jackson2JsonMessageConverter jsonMessageConverter = new Jackson2JsonMessageConverter();
		return jsonMessageConverter;
	}

	public static void main(String[] args) throws InterruptedException {
		SpringApplication.run(Application.class, args);
	}

}
