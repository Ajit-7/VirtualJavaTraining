package com.accenture.lkm.business.bean;

public class MessageBean {
	//actual payload
	private String message;
	private Employee employee;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
}
