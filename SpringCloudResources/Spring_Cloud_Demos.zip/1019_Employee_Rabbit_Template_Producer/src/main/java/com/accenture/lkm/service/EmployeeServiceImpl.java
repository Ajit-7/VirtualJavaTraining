package com.accenture.lkm.service;

import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.lkm.Application;
import com.accenture.lkm.business.bean.Employee;
import com.accenture.lkm.business.bean.MessageBean;

@Service
public class EmployeeServiceImpl {

	@Autowired
	private RabbitTemplate rabbitTemplate;

	@Autowired
	private TopicExchange topicExchange;
	
	@Autowired
	private Jackson2JsonMessageConverter jsonConv;
	
	public void addEmployee(Employee employee) {
		MessageBean bean = new MessageBean();
		bean.setEmployee(employee);
		bean.setMessage("This Employee is a new Employee");
		rabbitTemplate.setMessageConverter(jsonConv);
		//Sending to topic with a messageKey
		rabbitTemplate.convertAndSend(topicExchange.getName(), Application.messageKey, bean );
		System.out.println("Message is sent check the Queue in Rabbit MQ...");
	}

}

