package com.accenture.lkm.spring.web.config;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;

// The server issuing access tokens to the client after successfully authenticating the resource owner and obtaining authorization.
@Configuration
@EnableAuthorizationServer
public class AuthorizationServerConfiguration extends AuthorizationServerConfigurerAdapter {
    
	private static String REALM="MY_OAUTH_REALM";
       
    @Autowired
    private AuthenticationManager authenticationManager;
 
    //Registers a client with client-id: my-trusted-client, password: secret,  roles & scope allowed.
    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
    	clients
    	.inMemory()
        .withClient("my-trusted-client")
        .secret("secret")
            
        .authorizedGrantTypes("password", "authorization_code","refresh_token", "implicit")
        .authorities("ROLE_CLIENT", "ROLE_TRUSTED_CLIENT")
        .scopes("read", "write", "trust")
            
        //Access token is only valid for 2 minutes.
        .accessTokenValiditySeconds(120).
		
        // Refresh token is only valid for 10 minutes.
		refreshTokenValiditySeconds(600);

    }
   
    @Override
	public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
		endpoints
		.tokenStore(tokenStore())
		.accessTokenConverter(tokenEnhancer())
		.authenticationManager(authenticationManager);
	}

	public JwtTokenStore tokenStore() {
		return new JwtTokenStore(tokenEnhancer());
	}

	@Bean
	public JwtAccessTokenConverter tokenEnhancer() {
		JwtAccessTokenConverter converter = new JwtAccessTokenConverter();
		converter.setSigningKey("JAS@123");
		return converter;
	}
    
	//The only goal of this method is to define the realm in the sense of the HTTP/1.1
    @Override
    public void configure(AuthorizationServerSecurityConfigurer oauthServer) throws Exception {
        oauthServer.realm(REALM+"/client");
    }
}

