package com.accenture.lkm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Resilience4JProducer {

    public static void main(String[] args) {
        SpringApplication.run(Resilience4JProducer.class, args);
    }
}