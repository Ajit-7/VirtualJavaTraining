package com.lkm.accenture.service;

import java.io.IOException;


import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lkm.accenture.dao.EmployeeDAO;
import com.lkm.accenture.entity.EmployeeEntity;
import com.lkm.accenture.lkm.business.bean.Employee;
import com.lkm.accenture.lkm.business.bean.MessageBean;

@Component
public class EmployeeServiceReceiverImpl{

	@Autowired
	private EmployeeDAO dao;
	
    public EmployeeServiceReceiverImpl(){
    	System.out.println("From Receiver:> created"+this);
    }
    
    
    public void receiveMessage(byte[] obj) {
    	String mess=new String(obj);
        System.out.println("Received <" + mess + ">");
        MessageBean message=null;
		try {
			message = new ObjectMapper().readValue(mess,MessageBean.class);
			Employee  employee =  message.getEmployee();
	        
			EmployeeEntity employeeEntity = new  EmployeeEntity();
	        BeanUtils.copyProperties(employee, employeeEntity);
	        
	        dao.save(employeeEntity);
	        
	        System.out.println("Saved..");
        } catch (IOException e) {
			System.out.println(e.getMessage());
		}
    }
   

}
