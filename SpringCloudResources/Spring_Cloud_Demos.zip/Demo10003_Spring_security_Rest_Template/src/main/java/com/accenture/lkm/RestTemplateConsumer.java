package com.accenture.lkm;

import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import org.springframework.web.client.RestTemplate;

import com.accenture.lkm.error.handler.MyErrorHandle;
import com.accenture.lkm.model.Employee;

@SpringBootApplication
public class RestTemplateConsumer {

	public static final String REST_SERVICE_URI = "http://localhost:8095/emp/controller/";

	
	private static HttpHeaders getHeaders() {
		String username = "db_admin";
		String password = "db_admin";
		byte[] encodedBytes = Base64.getEncoder().encode((username + ":" + password).getBytes());
		String authHeader = "Basic " + new String(encodedBytes);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", authHeader);
		return headers;
	}

	/* GET */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void listAllEmployee() {
		System.out.println("Testing listAllUsers API-----------");
		RestTemplate restTemplate=new RestTemplate();
		restTemplate.setErrorHandler(new MyErrorHandle());
		HttpEntity<String> httpEntity = new HttpEntity<String>(getHeaders());
		ResponseEntity<List> responseEntity = restTemplate.
				exchange(REST_SERVICE_URI + "getDetails?", HttpMethod.GET,httpEntity, List.class);
		List<LinkedHashMap<String, Object>> employeeMMap = responseEntity.getBody();
		if (employeeMMap != null) {
			for (LinkedHashMap<String, Object> map : employeeMMap) {
				System.out.println("Employee : id=" + map.get("employeeId") + ", Name=" + map.get("employeeName")
						+ ", Salary=" + map.get("salary") + ", DepartmentCode=" + map.get("departmentCode"));
			}
			System.out.println(responseEntity.getStatusCode());
		} else {
			System.out.println("No employees exist----------");
		}
	}

	// GET
	private void getEmployee() {
		System.out.println("Testing getEmployee----------");
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setErrorHandler(new MyErrorHandle());
		HttpEntity<String> httpEntity = new HttpEntity<String>(getHeaders());
		ResponseEntity<Employee> responseEntity = restTemplate.exchange
				(REST_SERVICE_URI + "getDetailsById/1001", HttpMethod.GET,httpEntity, Employee.class);
		System.out.println(responseEntity.getBody());
		System.out.println(responseEntity.getStatusCode());
	}

	// POST
	private void createEmployee() {
		System.out.println("Testing create User API----------");
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setErrorHandler(new MyErrorHandle());
		Employee employee = new Employee("TestMSD", 0, 1000.0, 103);
		HttpEntity<Object> httpEntity = new HttpEntity<Object>(employee, getHeaders());

		ResponseEntity<String> responseEntity = restTemplate.exchange(REST_SERVICE_URI + "addEmp", HttpMethod.POST, httpEntity,String.class);
		System.out.println(responseEntity.getBody());
		System.out.println(responseEntity.getStatusCode());
	}

	// PUT
	private void updateEmployee() {
		System.out.println("Testing update User API----------");
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setErrorHandler(new MyErrorHandle());
		Employee employee = new Employee("UpdateMSD", 1002, 1000.0, 103);
		HttpEntity<Object> httpEntity = new HttpEntity<Object>(employee, getHeaders());
		ResponseEntity<Employee> responseEntity = restTemplate.exchange(REST_SERVICE_URI + "updateEmp", HttpMethod.PUT, httpEntity,Employee.class);
		System.out.println(responseEntity.getBody());
		System.out.println(responseEntity.getStatusCode());
	}

	// DELETE
	private void deleteUser() {
		System.out.println("Testing delete User API----------");
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setErrorHandler(new MyErrorHandle());
		HttpEntity<String> httpEntity = new HttpEntity<String>(getHeaders());
		ResponseEntity<Employee> responseEntity = restTemplate.
				exchange(REST_SERVICE_URI + "deleteEmp/1003", HttpMethod.DELETE,httpEntity, Employee.class);
		System.out.println(responseEntity.getBody());
		System.out.println(responseEntity.getStatusCode());
	}

	public static void main(String[] args) {
		ConfigurableApplicationContext applicationContext = SpringApplication.run(RestTemplateConsumer.class, args);
		RestTemplateConsumer consumer1 = applicationContext.getBean(RestTemplateConsumer.class, "restTemplateConsumer");
		
		try {
			
			consumer1.listAllEmployee();
			
			consumer1.getEmployee(); 
			
			consumer1.createEmployee();
			consumer1.updateEmployee();
			consumer1.deleteUser();
			
		}catch(RuntimeException e) {
			System.out.println(e.getMessage());
		}
		applicationContext.close();
	}
}