package com.accenture.lkm.custom.health.check;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

import com.accenture.lkm.model.Employee;
import com.accenture.lkm.service.EmployeeServiceImpl;

@Component//Part of component scan
public class CustomHealthCheckIndicator implements HealthIndicator{
	
	@Autowired
	private  EmployeeServiceImpl employeeServiceImpl;
	
	public CustomHealthCheckIndicator() {
		System.out.println("CustomHealthCheckIndicator constructor");
	}
	
	@Override
	public Health health() {
		System.out.println("Calling the Health Method of custom health check indicator");
		Collection<Employee> collectionEmployees = employeeServiceImpl.getEmployeeDetails();
		Health health= null;
		if(collectionEmployees ==null || collectionEmployees.isEmpty()){
			health=Health.down().withDetail("count",0).build(); 
		}
		else{
			health=Health.up().withDetail("count",collectionEmployees.size() ).build(); 
		}
		return health;
	}
}
