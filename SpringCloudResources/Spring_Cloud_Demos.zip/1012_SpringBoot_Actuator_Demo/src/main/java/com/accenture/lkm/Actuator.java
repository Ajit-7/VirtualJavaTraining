package com.accenture.lkm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Actuator {

    public static void main(String[] args) {
        SpringApplication.run(Actuator.class, args);
    }
}