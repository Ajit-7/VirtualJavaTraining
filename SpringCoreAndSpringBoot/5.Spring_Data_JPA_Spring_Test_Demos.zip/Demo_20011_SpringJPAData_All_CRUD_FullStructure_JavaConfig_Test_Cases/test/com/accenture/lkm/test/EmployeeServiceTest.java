package  com.accenture.lkm.test;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Collection;
import java.util.Date;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.lkm.business.bean.EmployeeBean;
import com.accenture.lkm.exception.EmployeeNotFoundException;
import com.accenture.lkm.service.EmployeeServiceImpl;
import com.accenture.lkm.spring.mainconf.SpringMainConfig;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes=SpringMainConfig.class)
// Following Annotation is used to run each test case in a individual Transaction
// with default strategy as rollback, as service layer is hitting DB layer
// changes done to database must be undone
@Transactional
public class EmployeeServiceTest {
	
	@Autowired
	private EmployeeServiceImpl empServiceIMPL;
	
	@Test
	public void testFindAll() throws Exception {
		System.out.println("***testFindAll()***");
		Collection<EmployeeBean> empList = empServiceIMPL.getAllEmployeeDetails();
		Assert.assertTrue(empList.size() > 0);
	}
	@Test
	public void testSaveValid() throws Exception {
		System.out.println("***testSaveValid()***");
		EmployeeBean bean = new EmployeeBean("MSD","TL", new Date(), 2345.0);
		EmployeeBean bean2 = empServiceIMPL.addEmployee(bean);
		Assert.assertNotNull(bean2);
	}
	@Test
	public void testFindByIdValid() throws Exception {
		System.out.println("***testFindByIdValid()***");
		EmployeeBean emp = empServiceIMPL.getEmployeeDetails(1001);
		Assert.assertNotNull(emp);
	}
	@Test
	public void testFindByIdInValid() throws Exception {
		System.out.println("***testFindByIdInValid()***");
		Exception exception = assertThrows(EmployeeNotFoundException.class, () -> {
			empServiceIMPL.getEmployeeDetails(5122);
	    });

	    String expectedMessage = "Entered EmployeeId doesn't exist, Please give a valid employeeId";
	    String actualMessage = exception.getMessage();

	    Assert.assertTrue(actualMessage.contains(expectedMessage));
	    
	}
}

//Remember for all the test cases Spring context will be loaded only once
//to reload the context you have to use dirties context annotation
//refer Spring-Test module documentation
//https://docs.spring.io/spring/docs/4.2.4.RELEASE/spring-framework-reference/html/integration-testing.html
