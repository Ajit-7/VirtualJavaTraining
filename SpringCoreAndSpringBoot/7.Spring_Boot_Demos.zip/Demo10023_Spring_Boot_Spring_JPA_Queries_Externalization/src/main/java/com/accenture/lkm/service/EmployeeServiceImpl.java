package com.accenture.lkm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.lkm.business.bean.Employee;
import com.accenture.lkm.dao.EmployeeDAOWrapper;
@Service
public class EmployeeServiceImpl {

	@Autowired
	private EmployeeDAOWrapper employeeDAOWrapper;
	
	// Query Methods:
	public List<Employee> getAllEmployeesBySalary(Double salary){
		return employeeDAOWrapper.getAllEmployeesBySalary(salary);
	}

	@SuppressWarnings("rawtypes")
	public List getDeptCodesAndCountOfEmployee(){
		return employeeDAOWrapper.getDeptCodesAndCountOfEmployee();
	}
	
	
}
