package com.accenture.lkm.test;

import java.util.Collection;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.MethodMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.lkm.Application;
import com.accenture.lkm.business.bean.EmployeeBean;
import com.accenture.lkm.service.EmployeeServiceImpl;

//Following Annotation is used to tell that Spring is used to run the tests 
@ExtendWith(SpringExtension.class)

// Following Annotation is replacement of @ContextConfiguration annotation
// it is used to point to the files having the configuration and helps to load and start the context
// Context will be cached for all test cases and classes
@SpringBootTest(classes=Application.class)

// Following Annotation is used to run each test case in a individual Transaction
// with default strategy as rollback, as service layer is hitting DB layer
// so changes done to database must be undone
@Transactional

//@Rollback(false)// can be used at the class level/method level to override the same

// Remember for all the test cases Spring context will be loaded only once
// to reload the context you have to use dirties context annotation
// @DirtiesContext(classMode=ClassMode.AFTER_CLASS)
public class EmployeeServiceTest {
	 
	@Autowired
	private EmployeeServiceImpl empServiceIMPL;

	@Test
	public void testAddEmployee() {
		EmployeeBean employee = new EmployeeBean("JAS", 0, 12345.0, 121);
		int employeeId = empServiceIMPL.addEmployee(employee);
		Assertions.assertTrue(employeeId>1003);
	} 
	
	@Test
	
	public void testFindAll() {
		Collection<EmployeeBean> empList = empServiceIMPL.getEmployeeDetails();
		Assertions.assertNotNull(empList);
	}
	
	@Test
	public void testFindByIdValid() {
		EmployeeBean employee = empServiceIMPL.getEmployeeDetailByEmployeeId(1001).orElse(null);
		Assertions.assertNotNull(employee);
	}
	
	@Test
	public void testFindByIdInvalid() {
		EmployeeBean employee = empServiceIMPL.getEmployeeDetailByEmployeeId(10007).orElse(null);
		Assertions.assertNull(employee);
	}
	@Test
	@DirtiesContext(methodMode = MethodMode.AFTER_METHOD)
	public void testUpdateInvalid() {
		EmployeeBean employee = new EmployeeBean("MSD", 10007, 2345.0, 123);
		EmployeeBean empUpdatedActualResult = empServiceIMPL.updateEmployee(employee).orElse(null);
		Assertions.assertNull(empUpdatedActualResult);
	}
	@Test
	public void testUpdateValid() {
		EmployeeBean employee = new EmployeeBean("XYZ", 1002, 2345.0, 123);
		EmployeeBean empUpdated = empServiceIMPL.updateEmployee(employee).orElse(null);
		Assertions.assertNotNull(empUpdated);
	}
	@Test
	public void testDeletevalid() {
		EmployeeBean empDeleted = empServiceIMPL.deleteEmployee(1001).orElse(null);
		Assertions.assertNotNull(empDeleted);
	}
	@Test
	public void testDeleteInvalid() {
		EmployeeBean empDeleted = empServiceIMPL.deleteEmployee(10007).orElse(null);
		Assertions.assertNull(empDeleted);
	}
}
