
package com.accenture.lkm.spring.config;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

//Part of component scan 
@Configuration
public class SpringConfig implements WebMvcConfigurer{
	
	public SpringConfig() {
		System.out.println("i am from SpringConfig ..");
	}
	@SuppressWarnings("deprecation")
	public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
	    configurer.favorPathExtension(true).//Enabling the Extension Based Strategy
	    favorParameter(false).//Disabling the parameter Based Strategy
	    ignoreAcceptHeader(true).//Disabling the Header Based Strategy
	    defaultContentType(MediaType.APPLICATION_JSON); 
	}
}
/*
https://www.baeldung.com/spring-mvc-content-negotiation-json-xml
https://spring.io/blog/2013/05/11/content-negotiation-using-spring-mvc
https://www.baeldung.com/web-mvc-configurer-adapter-deprecated
*/
/*
@SuppressWarnings("deprecation")
public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
    configurer.favorPathExtension(false).
    favorParameter(false).
    ignoreAcceptHeader(false).
    defaultContentType(MediaType.APPLICATION_JSON); 
}
*/