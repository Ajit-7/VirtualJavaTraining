package com.lkm.accenture.client;

import org.springframework.web.client.RestTemplate;

import com.accenture.lkm.bussiness.bean.Employee;

public class Tester1002 {
	public static final String REST_SERVICE_URI = "http://localhost:8095/emp/controller/";
	// GET 
	private static void getEmployee() {
		System.out.println("Testing getEmployee----------");
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setErrorHandler(new RestTemplateErrorHandler());//Custom error handle classes defined below
		//Placing Request and getting response
		Employee emp = restTemplate.getForObject(REST_SERVICE_URI + "getDetailsById/1009",Employee.class);
		System.out.println(emp);
	}

	//PUT 
	private static void updateEmployee() {
		System.out.println("Testing update User API----------");
		RestTemplate restTemplate = new RestTemplate();
		Employee employee = new Employee("MSDClient",10006, 7000.0,105);
		restTemplate.setErrorHandler(new RestTemplateErrorHandler());//Custom error handle classes defined below
		//Placing Request with a request body for Update
		restTemplate.put(REST_SERVICE_URI + "updateEmp", employee);
		System.out.println("Updated Successfuly!!!");
	}

	//DELETE 
	private static void deleteEmployee() {
		System.out.println("Testing delete User API----------");
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setErrorHandler(new RestTemplateErrorHandler());//Custom error handle classes defined below
		//Placing Request with a request body for deletion of Employee
		restTemplate.delete(REST_SERVICE_URI + "deleteEmp/10004");
		System.out.println("Deleted Successfuly!!!");
	}

	public static void main(String args[]) {
		
			//getEmployee();
			//updateEmployee();
			//deleteEmployee();
		
	}
}


//Step1 please don't put extra slashes in the end
//Step2  for appropriate request method on server side please choose appropriate request method
//example to invoke get method on server please use the getmethod on client
//Step3  please updated the employeeIds to be created/ updated/ deleted in the end of every URL
//put and delete do not return any thing hence showing null
