package com.lkm.accenture.client;

import java.io.IOException;

import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

public class RestTemplateErrorHandler implements ResponseErrorHandler{

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {
		System.out.println("I am in hasError()");
		if(response.getStatusCode()==HttpStatus.NOT_FOUND||response.getStatusCode()==HttpStatus.INTERNAL_SERVER_ERROR) {
			return true;
		}
		return false;
	}
	@Override
	public void handleError(ClientHttpResponse response) throws IOException {
		System.out.println("I am in handleError()");
		System.out.println("Employee with given id not exists to reterive/update/delete");
		System.exit(0);
	}


}
