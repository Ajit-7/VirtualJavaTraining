package com.accenture.lkm.customizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

//Step2: All Customizer should be Spring Components
@Component
@Profile("test_profile")
//Step1: All the Customizers should implement interface EmbeddedServletContainerCustomizer
public class TestCustomizer implements WebServerFactoryCustomizer<ConfigurableServletWebServerFactory> {
	
	private static Logger logger = LoggerFactory.getLogger("TestCustomizer");
	static {
		logger.info("********************************************");
		logger.info("Created the Test URL Customizer");
		logger.info("*********************************************");
	}
	// Step3: Override the method customize to override the
	// default context path and port 
    public void customize(ConfigurableServletWebServerFactory factory) {
    	factory.setContextPath("/spring-boot-test");
    	factory.setPort(8486);
     }
}