package com.accenture.lkm.dao;

import java.util.Collection;
import java.util.Optional;

import com.accenture.lkm.bussiness.bean.EmployeeBean;

public interface EmployeeDAO {

	Collection<EmployeeBean> getAllEmployee();
	Optional<EmployeeBean> getEmployeeDetailByEmployeeId(int employeeId);
	Integer addEmployee(EmployeeBean employee);
	Optional<EmployeeBean> deleteEmployee(int employeeId);
	Optional<EmployeeBean> updateEmployee(EmployeeBean employeeBean);

}