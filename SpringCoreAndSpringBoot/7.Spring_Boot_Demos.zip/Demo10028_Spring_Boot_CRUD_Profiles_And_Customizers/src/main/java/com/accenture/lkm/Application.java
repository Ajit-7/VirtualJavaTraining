package com.accenture.lkm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args); 
    }
}
//http://localhost:8484/spring-boot-prod/emp/controller/getDetails
//http://localhost:8486/spring-boot-test/emp/controller/getDetails