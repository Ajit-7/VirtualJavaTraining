package com.accenture.lkm.customizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

//Step2: All Customizer should be Spring Components
@Component
@Profile("prod_profile")
//Step1: All the Customizers should implement interface EmbeddedServletContainerCustomizer
public class ProdCustomizer implements WebServerFactoryCustomizer<ConfigurableServletWebServerFactory> {
	
	private static Logger logger = LoggerFactory.getLogger("ProdCustomizer");
	static {
		logger.info("********************************************");
		logger.info("Created the Production URL Customizer");
		logger.info("*********************************************");
	}
	// Step3: Override the method customize to override the
	// default context path and port 
    public void customize(ConfigurableServletWebServerFactory factory) {
    	factory.setContextPath("/spring-boot-prod");
    	factory.setPort(8484);
     }
}
//https://www.baeldung.com/embeddedservletcontainercustomizer-configurableembeddedservletcontainer-spring-boot