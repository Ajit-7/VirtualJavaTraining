package com.accenture.lkm;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.accenture.lkm.dao.EmployeeDAO;

@SpringBootApplication
public class Application {
	public static void main(String[] args) {
		
		//SpringApplication.run(Application.class, args);
		 
		SpringApplication app = new SpringApplication(Application.class);
		app.setBannerMode(Banner.Mode.OFF);

		// returns an instance of ConfigurableApplicationContext that can be used to
		// perform normal Spring operations.
		ConfigurableApplicationContext ctx = app.run(args);
		EmployeeDAO dao = (EmployeeDAO) ctx.getBean("employeeDAO");
		dao.getAllEmployee().forEach(System.out::println);

		System.out.println("Terminating the app");
		ctx.close();
	}
}