package com.accenture.lkm;

import org.springframework.boot.Banner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

import com.accenture.lkm.dao.EmployeeDAO;

@SpringBootApplication
public class Application {
	//Fluent Builder API 
    public static void main(String[] args) {
    	SpringApplicationBuilder app = new SpringApplicationBuilder()
    									.sources(Application.class)
    									.bannerMode(Banner.Mode.OFF);
        
    	ConfigurableApplicationContext ctx = app.run(args);
		EmployeeDAO dao = (EmployeeDAO) ctx.getBean("employeeDAO");
		dao.getAllEmployee().forEach(System.out::println);
		
		System.out.println("Terminating the app");
		ctx.close();
        
    }
}