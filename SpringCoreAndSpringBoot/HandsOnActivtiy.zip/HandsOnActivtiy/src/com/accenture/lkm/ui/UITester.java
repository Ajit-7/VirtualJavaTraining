package com.accenture.lkm.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.Student;

public class UITester {

	public static void main(String[] args) {

		ApplicationContext applicationContext = new 
				ClassPathXmlApplicationContext("com/accenture/lkm/resources/my_springbean.xml");
		
		Student student = applicationContext.getBean("student",Student.class);
		student.display();

		((ClassPathXmlApplicationContext)applicationContext).close();
	}

}
