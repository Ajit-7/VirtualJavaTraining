package com.accenture.lkm;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("student")
public class Student {

	@Value("1001")
	private Integer studentId;
	@Value("Ajit")
	private String studentName;
	@Value("Commerce")
	private String stream;

	public Integer getStudentId() {
		return studentId;
	}

	public void setEmployeeId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStream() {
		return stream;
	}

	public void setSalary(String stream) {
		this.stream = stream;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setEmployeeName(String studentName) {
		this.studentName = studentName;
	}

	public void display() {
		System.out.println("\nStudent Details are:");
		System.out.println("Student ID:" + this.studentId);
		System.out.println("Student Name:" + this.studentName);
		System.out.println("Student Stream:" + this.stream);
	}
}