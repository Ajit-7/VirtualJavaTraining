package com.accenture.lkm.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;

import com.accenture.lkm.entity.EmployeeEntity;


@RepositoryDefinition(idClass = Integer.class, domainClass = EmployeeEntity.class)
public interface EmployeeDAO {
	@Query(name="query1")
	List<EmployeeEntity> getAllEmployeesBySalary(Double salary); 
	// if more than one parameters are there then sequence of parameters in the method signature should match 
	// with the sequence of parameters in Query
	
	@Query(name="query2")
	List<EmployeeEntity> getAllEmployeesBySalary2(@Param("sal")Double salary); //Named Parameter
	
	@SuppressWarnings("rawtypes")
	@Query(name="query3") 
	List getRolesAndCountOfEmployeesInEachRole();
	

}
// if @query is not having a valid query then 
// then method signature is checked for the query method
// query translation 
	