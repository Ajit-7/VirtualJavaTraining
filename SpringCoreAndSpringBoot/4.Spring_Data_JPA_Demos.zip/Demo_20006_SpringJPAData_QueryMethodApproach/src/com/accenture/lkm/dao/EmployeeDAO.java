package com.accenture.lkm.dao;

import java.util.List;

import org.springframework.data.repository.RepositoryDefinition;

import com.accenture.lkm.entity.EmployeeEntity;

@RepositoryDefinition(idClass = Integer.class, domainClass = EmployeeEntity.class)
public interface EmployeeDAO {
	
	List<EmployeeEntity> findBySalaryGreaterThanEqual(Double salary);
	List<EmployeeEntity> findBySalaryGreaterThanEqualOrderByIdDesc(Double salary);
	List<EmployeeEntity> findByNameContainingOrderBySalaryDesc(String pattern);
	List<EmployeeEntity> findBySalaryGreaterThanEqualAndRole(Double param1,String param2);
	List<EmployeeEntity> findBySalaryBetween(Double param1, Double param2);

}
//name of the method is translated into query