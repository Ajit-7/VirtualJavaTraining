package com.accenture.lkm.service;

import java.util.List;

@SuppressWarnings("rawtypes")
public interface EmployeeService {
	List stringFunctions()throws Exception;
	List groupByExampleNamed()throws Exception;
}
