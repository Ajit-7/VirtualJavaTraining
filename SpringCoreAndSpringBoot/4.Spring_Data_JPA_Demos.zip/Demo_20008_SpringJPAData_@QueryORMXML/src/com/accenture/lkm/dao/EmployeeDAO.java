package com.accenture.lkm.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;

import com.accenture.lkm.entity.EmployeeEntity;

@SuppressWarnings("rawtypes")

@RepositoryDefinition(idClass = Integer.class, domainClass = EmployeeEntity.class)
public interface EmployeeDAO {
	@Query(name = "EmployeeDAO.stringFunctions")
	List stringFunctions();

	@Query(name = "EmployeeDAO.groupByExampleNamed")
	List groupByExampleNamed();

}
// if @query is not having a valid query then 
// then method signature is checked for the query method
// query translation 
