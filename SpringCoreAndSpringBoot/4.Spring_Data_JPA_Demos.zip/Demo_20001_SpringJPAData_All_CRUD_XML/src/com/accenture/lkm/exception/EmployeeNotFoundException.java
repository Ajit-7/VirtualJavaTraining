
package com.accenture.lkm.exception;

public class EmployeeNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

	public EmployeeNotFoundException() {
		super("Entered EmployeeId doesn't exist, Please give a valid employeeId");
	}

}
