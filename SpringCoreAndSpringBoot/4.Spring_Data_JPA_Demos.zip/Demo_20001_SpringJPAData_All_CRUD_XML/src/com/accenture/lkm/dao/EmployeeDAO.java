package com.accenture.lkm.dao;

import org.springframework.data.repository.CrudRepository;

import com.accenture.lkm.entity.EmployeeEntityBean;

public interface EmployeeDAO extends CrudRepository<EmployeeEntityBean, Integer>{ }
