package com.accenture.lkm.service;



public interface EmployeeService {
	 int updateSalary(Double salary,String name) throws Exception;
	 int updateSalary2(Double salary,String name) throws Exception;
}
